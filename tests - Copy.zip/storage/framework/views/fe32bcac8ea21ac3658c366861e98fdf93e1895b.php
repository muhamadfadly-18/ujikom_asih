
<?php $__env->startSection('content'); ?>
<div class="jumbotron">
  <h1 class="display-4">Hello, <?php echo e(Auth::user()->name); ?></h1>
  <p class="lead">Ini adalah halaman simple dashboard.</p>
  <hr class="my-4">
  <p>Anda login sebagai <?php echo e(Auth::user()->role); ?>.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend.app',[
	'title' => 'Welcome',
	'pageTitle' => 'Dashboard',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ujikom_asih\resources\views/user/index.blade.php ENDPATH**/ ?>